package com.example.assesment2.data.model

data class Entity(
    val property1: String,
    val property2: String,
    val description: String
)
