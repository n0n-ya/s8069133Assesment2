package com.example.assessment2.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.assessment2.R
import com.example.assessment2.databinding.ActivityLoginBinding // Ensure you have the correct import for View Binding
import com.example.assessment2.ui.dashboard.DashboardActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {
    private val viewModel: LoginViewModel by viewModels()
    private lateinit var binding: ActivityLoginBinding // Declare View Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater) // Initialize View Binding
        setContentView(binding.root)

        // Observe login result
        viewModel.loginResult.observe(this, Observer { keypass ->
            if (keypass != null) {
                // Navigate to DashboardActivity
                val intent = Intent(this, DashboardActivity::class.java).apply {
                    putExtra("keypass", keypass) // Pass the keypass if needed
                }
                startActivity(intent)
                finish() // Close LoginActivity
            }
        })

        // Observe error messages
        viewModel.errorMessage.observe(this, Observer { error ->
            if (error != null) {
                binding.errorTextView.text = error // Use the correct view reference
                binding.errorTextView.visibility = View.VISIBLE // Show the error message
            } else {
                binding.errorTextView.visibility = View.GONE // Hide the error message
            }
        })

        // Set click listener for the login button
        binding.loginButton.setOnClickListener {
            val username = binding.usernameEdittext.text.toString() // Use View Binding for username
            val password = binding.passwordEdittext.text.toString() // Use View Binding for password
            viewModel.login(username, password)
        }
    }
}
