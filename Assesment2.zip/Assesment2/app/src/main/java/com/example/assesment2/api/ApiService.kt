package com.example.assessment2.data.api


import com.example.assesment2.data.model.LoginRequest
import com.example.assesment2.data.model.LoginResponse
import com.example.assessment2.data.model.DashboardResponse


import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @POST("footscray/auth")
    suspend fun login(@Body loginRequest: LoginRequest): Response<LoginResponse>

    @GET("dashboard/{keypass}")
    suspend fun getDashboardData(@Path("keypass") keypass: String): Response<DashboardResponse>
}
