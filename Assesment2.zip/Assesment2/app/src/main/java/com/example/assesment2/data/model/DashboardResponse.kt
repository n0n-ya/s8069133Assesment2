package com.example.assessment2.data.model

import com.example.assesment2.data.model.Entity

data class DashboardResponse(
    val entities: List<Entity>,  // A list of Entity objects
    val entityTotal: Int         // Total number of entities
)
