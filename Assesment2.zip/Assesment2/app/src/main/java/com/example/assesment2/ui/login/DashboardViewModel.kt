package com.example.assessment2.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import com.example.assessment2.data.api.ApiService
import com.example.assessment2.data.model.DashboardResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(private val apiService: ApiService) : ViewModel() {

    private val _dashboardData = MutableLiveData<DashboardResponse?>()
    val dashboardData: LiveData<DashboardResponse?> = _dashboardData

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    fun getDashboardData(keypass: String) {
        viewModelScope.launch {
            try {
                val response: Response<DashboardResponse> = apiService.getDashboardData(keypass)
                if (response.isSuccessful) {
                    _dashboardData.value = response.body()
                } else {
                    _errorMessage.value = "Failed to fetch dashboard data: ${response.code()}"
                }
            } catch (e: Exception) {
                _errorMessage.value = "An error occurred: ${e.message}"
            }
        }
    }
}
