package com.example.assesment2.data.model

data class LoginRequest(
    val username: String,
    val password: String
)
